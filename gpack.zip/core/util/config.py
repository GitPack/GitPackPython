class Config(object):
    def __init__(self, data):
        self.key = data["key"]
