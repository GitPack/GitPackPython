import sys
import os
import gpack

if __name__ == "__main__":
    gpack.main(sys.argv[1:])